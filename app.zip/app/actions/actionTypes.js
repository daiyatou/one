/**
 * Created by jason  on 16/7/14.
 * action类型
 */
//主页actions
export const FETCH_HOME_LIST = 'FETCH_HOME_LIST';
export const RECEIVE_HOME_LIST = 'RECEIVE_HOME_LIST';
// //详情页actions
// export const FETCH_DETIAL_DATE = 'FETCH_DETIAL_DATE';
// export const RECEIVE_DETIAL_DATE = 'RECEIVE_DETIAL_DATE';
//分类页actions
export const FETCH_CLASS_LIST = 'FETCH_CLASS_LIST';
export const RECEIVE_CLASS_LIST = 'RECEIVE_CLASS_LIST';

//分类详细页actions

export const FETCH_CLASSDITAL_LIST = 'FETCH_CLASSDITAL_LIST';
export const RECEIVE_CLASSDITAL_LIST = 'RECEIVE_CLASSDITAL_LIST';
export const RESET_CLASSDITAL_STATE = 'RESET_CLASSDITAL_STATE'; 
