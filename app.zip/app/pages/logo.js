import React, {Component} from 'react';
import {StyleSheet, Text, Image, ListView, TouchableOpacity, View, InteractionManager,  Dimensions,TextInput, Navigator} from 'react-native';

import Common from '../common/common';
import HeaderView from '../common/HeaderView';
